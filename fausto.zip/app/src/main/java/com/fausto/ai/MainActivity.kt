package com.fausto.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var pvEt: EditText
    private lateinit var voiceEt: EditText
    private lateinit var alwaysCb: CheckBox
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: String) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color))
    }

    private fun field(hint: String, value: String, secret: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine()
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fausto", MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(28), dp(20), dp(28))
        fun add(v: View, top: Int = 10) {
            root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) })
        }

        add(label("FAUSTO", 28f, "#B07CFF"), 0)
        keyEt = field("Gemini API anahtarı (AIza...)", prefs.getString("gemini_key", "").orEmpty(), true)
        modelEt = field("Model (boş bırak, otomatik seçilir)", prefs.getString("model", "").orEmpty(), false)
        pvEt = field("Picovoice AccessKey (uyandırma için)", prefs.getString("pv_key", "").orEmpty(), true)
        alwaysCb = CheckBox(this).apply {
            text = "Küre her zaman görünsün"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("always", false)
        }
        voiceEt = field("Erkek ses adı (boş: Charon; Orus, Algenib, Fenrir da denenebilir)", prefs.getString("voice", "").orEmpty(), false)
        add(keyEt, 20); add(modelEt); add(pvEt); add(voiceEt)
        add(btn("Fausto.ppn (uyandırma dosyası) seç") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 7)
        })
        add(alwaysCb)
        add(label("İzinler", 16f, "#FF4466"), 18)
        add(btn("1) Diğer uygulamaların üstünde göster") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(btn("2) Erişilebilirlik > Fausto'yu aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        add(btn("3) Pil optimizasyonunu kapat") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        add(btn("BAŞLAT") { start() }, 18)
        add(btn("DURDUR") { stopService(Intent(this, FaustoService::class.java)); toast("Fausto durdu") })
        status = label("", 13f, "#CCCCCC")
        add(status, 18)

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0B12")); addView(root) })
    }

    override fun onResume() {
        super.onResume()
        fun t(b: Boolean) = if (b) "✓" else "✗"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Üstte gösterme: ${t(Settings.canDrawOverlays(this))}\n" +
            "Erişilebilirlik: ${t(FaustoAccess.instance != null)}\n" +
            "Mikrofon: ${t(mic)}\n" +
            "Uyandırma dosyası: ${t(File(filesDir, "fausto.ppn").exists())}"
    }

    private fun save() {
        prefs.edit()
            .putString("gemini_key", keyEt.text.toString().trim())
            .putString("model", modelEt.text.toString().trim())
            .putString("pv_key", pvEt.text.toString().trim())
            .putString("voice", voiceEt.text.toString().trim())
            .putBoolean("always", alwaysCb.isChecked)
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun start() {
        save()
        if (!Settings.canDrawOverlays(this)) { toast("Önce 1) numaralı izni ver"); return }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        startForegroundService(Intent(this, FaustoService::class.java))
        toast("Fausto çalışıyor. 'Hey Fausto' de!")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
        else toast("Mikrofon izni gerekli")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { i ->
                    File(filesDir, "fausto.ppn").outputStream().use { o -> i.copyTo(o) }
                }
                toast("Uyandırma dosyası kaydedildi")
                onResume()
            } catch (e: Exception) { toast("Dosya okunamadı: ${e.message}") }
        }
    }
}
